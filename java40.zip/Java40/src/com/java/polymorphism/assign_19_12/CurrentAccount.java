package com.java.polymorphism.assign_19_12;

public class CurrentAccount extents BankAccount
{

}
